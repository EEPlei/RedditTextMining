# using "testthat" for tests
# tests are located in inst/tests

library(testthat)
library(Rhipe)

test_package("Rhipe")
